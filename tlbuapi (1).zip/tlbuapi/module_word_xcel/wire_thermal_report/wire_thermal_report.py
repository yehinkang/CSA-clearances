import json
import os
import numpy as np
from datetime import datetime

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .commons import report_docx_general


def get_thermal_rating_report(json_input=None):
    '''
    input: json_input that is the thermal calc result returned from API
           json_input has an optional item: url_home = homepage of ECS
    '''

    # json_input is the result per thermal calcs
    if json_input is None:
        return None

    if not ('user_input' in json_input) or not ('analysis_results' in json_input):
        return None

    user_input = json_input['user_input']
    analy_rst = json_input['analysis_results']

    plot_thermal_png = _plot_curve_thermal_rating(dict_therm_rst=json_input)
    report_data = _get_report_content_thermal(dict_therm_rst=json_input)

    filename_docx = 'tmp/' + datetime.utcnow().strftime('utc_%Y%m%d_%H%M%S') + '_therm_report.docx'

    report_docx = report_docx_general.ReportDocx(file_path=filename_docx, report_title='Thermal Rating Calc Result',
                                                 img_cover=plot_thermal_png)
    if 'url_home' in json_input:
        url_home_ecs = json_input['url_home']
    else:
        url_home_ecs = None

    report_docx.create_report_cover(url=url_home_ecs, app_name='Thermal Rating')

    section_title = _get_thermal_rating_title(user_input=user_input)
    report_docx.write_report_section(report_data=report_data, section_title=section_title,
                                     space_pt_before=0, space_pt_after=2)

    report_docx.insert_image(img_path=plot_thermal_png, inch_width=6.0,
                             para_comment=None)

    if os.path.isfile(filename_docx):
        response = {
            'instruction': '[Ctrl + click] the link to download the result',
            'link_download': None,
            'platform': '0',
            'file_to_download': filename_docx
        }

    else:
        response = {
            'instruction': 'No report has been created. Check input format.',
            'link_download': None,
            'platform': '0',
            'file_to_download': None
        }

    return response


def _get_thermal_rating_title(user_input=None):
    if user_input is None:
        return None

    list_mdthods = ['IEEE Standard 738-2006',
                    'IEEE Standard 738-2012',
                    'CIGRE Brochure 207 (8/2002)',
                    'CIGRE Brochure 601 (12/2014)',
                    'TNSP 2009']
    id_method = user_input['option_method']

    try:
        title = list_mdthods[int(id_method)]
    except Exception as e:
        title = None
        print()
    title = f'Analysis Result according to {title}'

    return title


def _get_report_content_thermal(dict_therm_rst=None):
    if dict_therm_rst is None:
        return None

    user_input = dict_therm_rst['user_input']
    analy_rst = dict_therm_rst['analysis_results']

    # input content is a list of dictionaries
    # weather conditions
    atm_type = 'Clear' if user_input['option_atm']=='0' else 'Industrial'
    content_input = [
        {'bold': True, 'text': 'Weather Conditions'},
        {'bold': False,
        'text': f'Air temperature: {user_input["temperature_air"]} (\u00B0F)'},
        {'bold': False,
        'text': f'Wind speed: {user_input["speed_wind"]} (psf)'},
        {'bold': False,
        'text': f'Wind angle to conductor: {user_input["angle_wind_to_cond"]} (deg)'},
        {'bold': False,
        'text': f'Atmosphere type: {atm_type}'}]

    # Solar conditions
    content_input.append({'bold': True, 'text': "Solar Conditions"})
    content_input.append({
        'bold':False,
        'text': f'Date: {user_input["date_solar"]}'})
    content_input.append({
        'bold': False,
        'text': f'Day of year: {user_input["day_of_year"]}'})
    content_input.append({
        'bold': False,
        'text': f'Sun time: {user_input["suntime"]} (hours)'})
    content_input.append({
        'bold': False,
        'text': f'Altitude: {user_input["altitude"]} (deg)'})
    content_input.append({
        'bold': False,
        'text': f'Azimuth: {user_input["azimuth"]} (deg)'})

    # Conductor data
    content_input.append({
        'bold': True,
        'text': 'Conductor Properties'})
    content_input.append({
        'bold': False,
        'text': f'Description: {user_input["wire_desc"]}'})
    content_input.append({
        'bold': False,
        'text': f'Conductor elevation: {user_input["elevation"]} (ft)'
    })
    content_input.append({
        'bold': False,
        'text': f'Conductor azimuth: {user_input["solar_azimuth_constant"]}'})
    content_input.append({
        'bold': False,
        'text': f'AC resistance at {user_input["low_temp_ac_resistance"]}\u00B0C: {user_input["ac_resistance_at_low_temp"]} (ohm/mile)'})

    content_input.append({
        'bold': False,
        'text': f'AC resistance at {user_input["high_temp_ac_resistance"]}\u00B0C: {user_input["ac_resistance_at_high_temp"]} (ohm/mile)'})
    content_input.append({
        'bold': False,
        'text': f'Solar absorptivity: LATER'})

    content_input.append({
        'bold': False,
        'text': f'Emissivity: LATER'})

    content_input.append({
        'bold': False,
        'text': f'Outer diameter: LATER (in)'})

    content_input.append({
        'bold': False,
        'text': f'Outer strand diameter: LATER (in)'})

    content_input.append({
        'bold': False,
        'text': f'Outer strand layers: LATER'})

    content_input.append({
        'bold': False,
        'text': f'Outer surface finish: LATER'})

    content_input.append({
        'bold': False,
        'text': f'Outer heat capacity: LATER (W-s/ft-deg)'})

    content_input.append({
        'bold': False,
        'text': f'Cable is thermal bimetallic: LATER'})

    content_input.append({
        'bold': False,
        'text': f'Core diameter: LATER (in)'})

    report_part1 = {'istable': False,
                    'title': 'USER INPUT',
                    'content': content_input}

    # Analysis result
    content_rst = [
        {'bold': True,
         'text': 'Analysis Resutls'},
        {'bold': False,
         'text': f'Current: {analy_rst["current"]} (Amps)'},
        {'bold': False,
         'text': f'Conductor temperature: {analy_rst["temperature_cond"]} (\u00B0F)'},
        {'bold': False,
        'text': f'Convection cooling: {analy_rst["cooling_convective"]}(W/ft)'},
        {'bold': False,
        'text': f'Radiative cooling: {analy_rst["cooling_radiative"]} (W/ft)'},
        {'bold': False,
         'text': f'Solar heating: {analy_rst["heating_solar"]} (W/ft)'},
        {'bold': False,
         'text': f'Equivalent global solar radiation: {analy_rst["global_solar_radiation"]} (W/ft^2)'},
        {'bold': False,
         'text': f'Final conductor azimuth: {user_input["azimuth"]} (deg)'},
        {'bold': False,
         'text': f'Final solar absorptivity: {analy_rst["absorp_applied"]}'},
        {'bold': False,
         'text': f'Final emissivity: {analy_rst["emmiss_applied"]}'},
        {'bold': False,
         'text': f'Final wind to conductor angle: {user_input["angle_wind_to_cond"]} (deg)'}]

    report_part2 = {'istable': False,
                    'title': 'OUTPUT',
                    'content': content_rst}

    content_msg = []
    if len(analy_rst['errors']) == 0:
        content_msg = [{'bold': False, 'text': 'N.A.'}]
    else:
        for msg in analy_rst['errors']:
            content_msg.append({'bold': False, 'text': msg})
    report_part3 = {'istable': False,
                    'title': 'Additional notes',
                    'content': content_msg}
    report_data = [report_part1, report_part2, report_part3]

    return report_data


def _plot_curve_thermal_rating(dict_therm_rst=None):
    if dict_therm_rst is None:
        return None

    user_input = dict_therm_rst['user_input']
    curve_data = dict_therm_rst['curve_data']
    # convert data (x,y) pairs to [x] and [y] in np array format
    data_np_array = np.asarray(curve_data).T
    fig, ax = plt.subplots()
    ax.plot(data_np_array[0], data_np_array[1], color='red')

    if user_input['option_calc_type'] == '0':
        xlabel = 'Current (A)'
        ylabel = f'Temperature (\u00BAF)'
        title = 'Steady State Conductor Temperature'
    else:
        xlabel = f'Temperature (\u00BAF)'
        ylabel = 'Current (A)'
        title = 'Steady State Thermal Rating'
    ax.set(xlabel=xlabel, ylabel=ylabel, title=title)
    ax.grid()
    filename_plot = 'tmp/' + datetime.utcnow().strftime('utc_%Y%m%d_%H%M%S') + '_plot.png'
    fig.savefig(filename_plot)

    return filename_plot

