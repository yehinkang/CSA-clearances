import os

from commons import report_docx_general

def create_doc_word():
    filename = 'report_auto_generated.docx'
    file_docx = report_docx_general.ReportDocx(file_path=filename,
                                            report_title='Testing Docx Generator Interface',
                                            img_cover='icon_tower.png')
    # test for coversheet
    file_docx.create_report_cover(url='https://josephdong.azurewebsites.net/', img_width=3.5)

    # test for section
    section_title = 'New Section Starts Here'
    data_text = [{'bold': True,
                'text': "Bold: This is a text paragraph as one of the subsections"},
                {'bold': False, 'indent_1': 16,
                'text': "Normal: This is a text paragraph as one of the subsections"}
                ]
    data_table = [['data 11', 'data 12', 'data 13'],
                ['data 21', 'data 22', 'data 23']]

    section_data = [
        {'istable': False,
        'title': 'Subsection (Text Only)',
        'content': data_text},
        {'istable': True,
        'title': 'Subsection (Table)',
        'header': ['column 1', 'column 2 - wide column', 'column 3'],
        'tablefooter':['table footer line 1', 'table footer line 2...'],
        'content': data_table}
    ]

    file_docx.write_report_section(report_data=section_data, section_title=section_title)
    print(f'The test word file is created and saved as {filename}')


if __name__ == '__main__':
    # uncomment the line below to show help string
    # help(report_docx_general)

    create_doc_word()