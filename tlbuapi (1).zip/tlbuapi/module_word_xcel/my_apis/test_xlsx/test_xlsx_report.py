import os

from commons import report_xlsx_general

# Comment line below to surpass HELP INFO
# help(report_xlsx_general)

# define output filename
filename = 'report_auto_generated.xlsx'

# define data to be included in worksheet
ws_data0 = [
    ['First Worksheet'],
    ['cell00', 'cell01', 'cell02', 'cell03', 'cell04'],
    ['cell10', 'cell11', 'cell12', 'cell13', 'cell14'],
    ['cell20', 'cell21', 'cell22', 'cell23', 'cell24'],
    ['cell30', 'cell31', 'cell32', 'cell33', 'cell34']
]
ws_data1 = [
    ['Second Worksheet'],
    ['data00', 'data01', 'data02', 'data03', 'data04'],
    ['data10', 'data11', 'data12', 'data13', 'data14'],
    ['data20', 'data21', 'data22', 'data23', 'data24'],
    ['data30', 'data31', 'data32', 'data33', 'data34']
]
n_row = len(ws_data0)
n_column = len(ws_data0[1])

# define some colors for background fill
color_bkg_header = 'E0E0E0'
color_bkg_data_1 = 'CCE5FF'
color_bkg_data_2 = 'CCFFFF'
list_range_color = []
for i in range(n_row-1):
    if i % 2 == 0:
        list_range_color.append((i+1, 1, i+1, n_column, color_bkg_data_1))
    else:
        list_range_color.append((i + 1, 1, i + 1, n_column, color_bkg_data_2))

# define cell format
cell_format = {
    'range_merge': [(1, 1, 1, n_column, 'center')],
    'range_font_bold': [(1, 1, 1, 1)],
    'range_color': list_range_color,
    'range_border': [(1, 1, 1, n_column), (2, 1, n_row, n_column)],
    'row_height': [(1, 35)],
    'column_width': [(i+1, 20) for i in range(n_column)],
}

# define some footer notes
footer = ['Footer note line 1', 'Add more lines for footer notes']

# define two worksheets
ws0 = {
    'ws_name': 'worksheet1',
    'ws_content': ws_data0,
    'cell_range_style': cell_format,
    'footer': footer
}

ws1 = {
    'ws_name': 'worksheet2',
    'ws_content': ws_data1,
    'cell_range_style': cell_format,
    'footer': footer
}

# define workbook content - a list of worksheets
workbook_content = [ws0, ws1]

report_xlsx_general.create_workbook(workbook_content=workbook_content, filename=filename)

