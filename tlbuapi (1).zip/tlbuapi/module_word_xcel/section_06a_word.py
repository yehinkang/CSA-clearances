'''
Jan 13, 2022 - demonstration of word document creation

Three often-used methods in ReportDocx class:
    -) create_report_cover()
    -) write_report_section()
    -) insert_image()
'''

from commons import report_docx_general

# Comment below line to skip the documentation info
help(report_docx_general)

file_docx = report_docx_general.ReportDocx(file_path='test.docx', report_title='Training Section 06',
                                           img_cover='icon_tower.png')

section_title = 'New Section Starts Here'
data_text = [
    {'bold': True, 'text': 'Bold - This is a text paragraph as one of the subsections'},
    {'bold': False,  'indent_l': 16, 'text': 'Normal text: this is a paragraph'}
]

data_table = [
    ['data 11', 'data 12', 'data 13'],
    ['data 21', 'data 22', 'data 23']
]

section_data = [
    {'istable': False, 'title': 'A section title', 'content': data_text},
    {'istable': True, 'title': 'Table title', 'header': ['col 1', 'col 2', 'col 3'],
     'tablefooter': ['table footer note 1', 'table footer 2'],
     'content': data_table}
]

file_docx.create_report_cover(img_width=2.5)
file_docx.write_report_section(report_data=section_data, section_title=section_title)
